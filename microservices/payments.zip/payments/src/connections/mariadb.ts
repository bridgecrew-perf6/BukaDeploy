// Use the MariaDB Node.js Connector
var mariadb = require('mariadb');
 
// Create a connection pool
const pool = mariadb.createPool({
    host: "mariadb", 
    port: 3306,
    user: "root", 
    password: "DbAdmin69",
    database: "Users"
  });
export default Object.freeze({
    pool: pool
  });
  