import express, { Express, Request, Response, Router, NextFunction } from 'express';
import paypal, { Payment} from 'paypal-rest-sdk';

var router: Router = express.Router()

/* GET home page */
router.get('/error', function(req: Request, res: Response, next: NextFunction) {
    res.send('Error during the payment request');
});

router.get('/', async function(req: Request, res: Response, next: NextFunction) {
    try {

        var payment_json: Payment = {
            intent: 'sale',
            payer: { 
                payment_method: 'paypal'
            },
            redirect_urls: { 
                return_url: 'http://localhost:3006/finalize',
                cancel_url: 'http://localhost:3006/error',
            },
            transactions: [{
                amount: {
                    total: '39.00',
                    currency: 'USD'
                },
                description: 'test payment'
            }]
        }
    
        paypal.payment.create(payment_json, function  (error, payment: any) {
            if (error) {
                throw error;
            } else {
                

                for(let i = 0;i < payment.links.length;i++){
                  if(payment.links[i].rel === 'approval_url'){
                    console.log(payment)

                    res.redirect(payment.links[i].href);
                  }
                }
            }
          });
          
    } catch (err) {
        console.log(err);
        res.status(500).send({ error:  'Internal Server Error' });
    }

});

router.get('/finalize', function(req: Request, res: Response, next: NextFunction) {
    const db = req.app.get('db');

    const paymentId = req.query.paymentId!.toString();
    paypal.payment.get(paymentId, function(error, payment) {
        if(error) {
            console.log(error);
            throw error;
        } else {
            const results = db.pool.query("INSERT INTO payments (user_id, content, address, amount) values (?,?,?,?)", 
            [
                '1', //req.body.user.id,
                JSON.stringify([
                    {name:'burger', price: '10.00', quantity: 1}]),
                'address', //req.body.user.address
                payment.transactions[0].amount.total
            ])
            res.send(payment);
        }
     });

});

export default router;
