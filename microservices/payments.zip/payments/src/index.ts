import express, { Express, Request, Response } from 'express';
import paypal from 'paypal-rest-sdk';
import bodyParser from 'body-parser';
import mariadbConnection from './connections/mariadb';

import indexRouter from './routes/index';

const app: Express = express();
const port: Number = 3006;

paypal.configure({
    'mode': 'sandbox',
    'client_id': process.env.PAYPAL_CLIENT_ID!,
    'client_secret': process.env.PAYPAL_CLIENT_SECRET!
});

app.use('/', indexRouter);

app.use(bodyParser.json());

app.set('db', mariadbConnection);

app.listen(port, () => {
    console.log('[server]: The server is running at http://localhost:' + port);
});
